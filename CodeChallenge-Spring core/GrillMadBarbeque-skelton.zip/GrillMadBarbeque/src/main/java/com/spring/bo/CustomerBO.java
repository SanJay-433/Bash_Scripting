package com.spring.bo;

import com.spring.model.Customer;

//Use proper annotation
public class CustomerBO {

	public double calculateTotalBillAmount(Customer cObj) {
		// Fill the code here
		return 0;
	}

}
