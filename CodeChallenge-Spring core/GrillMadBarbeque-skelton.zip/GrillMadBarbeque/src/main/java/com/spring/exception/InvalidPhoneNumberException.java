package com.spring.exception;

public class InvalidPhoneNumberException extends Exception {
	public InvalidPhoneNumberException(String msg) {
		// Fill the code here
	}

}

