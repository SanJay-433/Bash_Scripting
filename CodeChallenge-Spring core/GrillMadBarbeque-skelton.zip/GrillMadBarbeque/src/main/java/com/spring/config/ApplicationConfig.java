package com.spring.config;

//Fill the code here
public class ApplicationConfig {

}
