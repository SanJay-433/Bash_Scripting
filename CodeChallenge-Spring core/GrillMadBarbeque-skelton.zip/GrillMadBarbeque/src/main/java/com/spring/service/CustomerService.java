package com.spring.service;

import com.spring.bo.CustomerBO;

//Use proper annotation

public class CustomerService {

	private CustomerBO customerBoObj;

	public CustomerBO getCustomerBoObj() {
		return customerBoObj;
	}

	public void setCustomerBoObj(CustomerBO customerBoObj) {
		this.customerBoObj = customerBoObj;
	}

	public double calculateTotalBillAmount(String customerName, String mailId, String customerType, String phoneNumber,
			String comboType) {
		// Fill the code here
		return 0;
	}
}
