package com.spring.model;

import java.util.Map;

//Use proper annotation

public class PriceInfo {

//Use proper annotation

	private Map<String, Double> priceDetails;

	public Map<String, Double> getPriceDetails() {
		return priceDetails;
	}

	public void setPriceDetails(Map<String, Double> priceDetails) {
		this.priceDetails = priceDetails;
	}

}
