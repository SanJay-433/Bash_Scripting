package com.spring.config;

// fill the code
public class ApplicationConfig {

}
