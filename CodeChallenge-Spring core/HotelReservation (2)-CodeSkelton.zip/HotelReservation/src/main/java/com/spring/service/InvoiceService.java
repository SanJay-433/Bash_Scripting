package com.spring.service;

import com.spring.bo.InvoiceBO;

public class InvoiceService {

	private InvoiceBO invoiceBoObj;

	public InvoiceBO getInvoiceBoObj() {
		return invoiceBoObj;
	}

	public void setInvoiceBoObj(InvoiceBO invoiceBoObj) {
		this.invoiceBoObj = invoiceBoObj;
	}

	public double calculateTotalBill(String reservationId, int stayDaysCount, String roomType) {

		// Fill the code here
		return 0;
	}

}
