package com.spring.bo;

import com.spring.model.Invoice;

public class InvoiceBO {
    
	public double calculateTotalBill(Invoice invoiceObj, String roomType) {
		
		// Fill the code here
		
		return 0;
	}

}
