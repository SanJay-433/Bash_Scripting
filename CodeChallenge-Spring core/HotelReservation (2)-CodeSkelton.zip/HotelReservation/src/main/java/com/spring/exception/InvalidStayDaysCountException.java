package com.spring.exception;

public class InvalidStayDaysCountException extends Exception {

	public InvalidStayDaysCountException(String msg) {
		// Fill the code here
	}

}
