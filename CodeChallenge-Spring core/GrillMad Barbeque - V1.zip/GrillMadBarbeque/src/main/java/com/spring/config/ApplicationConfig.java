package com.spring.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan({"com.spring.bo","com.spring.model","com.spring.service"})
@PropertySource({ "classpath:priceInfo.properties" })
public class ApplicationConfig 
{

}

//package com.spring.config;
//
//public class ApplicationConfig 
//{
//
//}
